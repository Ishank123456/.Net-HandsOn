﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleRentalService_Wipro_Assesment
{
    public class RentalTransaction
    {
        public int TransactionId { get; set; }
        public int CustomerId { get; set; }
        public string VehicleRegistrationNumber { get; set; }
        public DateTime RentalStartDate { get; set; }
        public DateTime RentalEndDate { get; set; }
        public decimal TotalAmount { get; set; }

        public RentalTransaction(int transactionId, int customerId, string vehicleRegistrationNumber, DateTime rentalStartDate, DateTime rentalEndDate, decimal totalAmount)
        {
            if (rentalStartDate >= rentalEndDate)
                return;

            TransactionId = transactionId;
            CustomerId = customerId;
            VehicleRegistrationNumber = vehicleRegistrationNumber;
            RentalStartDate = rentalStartDate;
            RentalEndDate = rentalEndDate;
            TotalAmount = totalAmount;
        }
    }
}
