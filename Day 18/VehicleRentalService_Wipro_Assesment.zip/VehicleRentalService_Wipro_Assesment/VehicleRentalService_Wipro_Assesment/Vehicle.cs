﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleRentalService_Wipro_Assesment
{
    public class Vehicle
    {
        public string RegistrationNumber { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public decimal RentalPricePerDay { get; set; }


        // Primary Constructor
        public Vehicle(string registrationNumber, string make, string model, int year, decimal rentalPricePerDay)
        {
            if (!ValidateRegistrationNumber(registrationNumber))
                return;
            if (year < 2000 || year > DateTime.Now.Year)
                return;
            if (rentalPricePerDay <= 0)
                return;

            RegistrationNumber = registrationNumber;
            Make = make;
            Model = model;
            Year = year;
            RentalPricePerDay = rentalPricePerDay;
        }

        // Copy Constructor
        public Vehicle(Vehicle existingVehicle)
        {
            RegistrationNumber = existingVehicle.RegistrationNumber;
            Make = existingVehicle.Make;
            Model = existingVehicle.Model;
            Year = existingVehicle.Year;
            RentalPricePerDay = existingVehicle.RentalPricePerDay;
        }

        // Validation Method
        private bool ValidateRegistrationNumber(string registrationNumber)
        {
            // Assuming vehicle registration format (e.g., WB09HJ1234)
            return registrationNumber.Length == 10 && char.IsLetter(registrationNumber[0]) && char.IsLetter(registrationNumber[1]);
        }
    }
}
