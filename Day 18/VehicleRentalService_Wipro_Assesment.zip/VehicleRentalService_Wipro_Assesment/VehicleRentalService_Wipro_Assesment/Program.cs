﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleRentalService_Wipro_Assesment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var rentalService = new RentalService();
            rentalService.LoadAndInvokeDynamicMethods();
            rentalService.OnRentalProcessed += message => Console.WriteLine($"[Notification] {message}");
            rentalService.OnRentalCompleted += message => Console.WriteLine($"[Notification] {message}");
            rentalService.LoadTransactionsFromFile(@"C:\Wipro Training\transactions.txt");
            while (true)
            {
                Console.WriteLine("\n--- Vehicle Rental Service ---");
                Console.WriteLine("1. Add Customer");
                Console.WriteLine("2. Add Vehicle");
                Console.WriteLine("3. Rent Vehicle");
                Console.WriteLine("4. Return Vehicle");
                Console.WriteLine("5. View Customer Details");
                Console.WriteLine("6. View Vehicle Details");
                Console.WriteLine("7. View Transaction Details");
                Console.WriteLine("8. Save Transactions to File");
                Console.WriteLine("9. Exit");
                Console.Write("Choose an option: ");
                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddCustomer(rentalService);
                        break;
                    case 2:
                        AddVehicle(rentalService);
                        break;
                    case 3:
                        RentVehicle(rentalService);
                        break;
                    case 4:
                        ReturnVehicle(rentalService);
                        break;
                    case 5:
                        ViewCustomerDetails(rentalService);
                        break;
                    case 6:
                        ViewVehicleDetails(rentalService);
                        break;
                    case 7:
                        ViewTransactionDetails(rentalService);
                        break;
                    case 8:
                        rentalService.SaveTransactionsToFile(@"C:\Users\hp\Documents\Transactions\transactions.txt");
                        Console.WriteLine("Transactions saved to file.");
                        break;
                    case 9:
                        return;
                }
            }
        }

        static void AddCustomer(RentalService rentalService)
        {
            Console.Write("Enter Customer ID: ");
            int customerId = int.Parse(Console.ReadLine());
            Console.Write("Enter Customer Name: ");
            string name = Console.ReadLine();
            Console.Write("Enter Phone Number: ");
            string phoneNumber = Console.ReadLine();
            Console.Write("Enter Email: ");
            string email = Console.ReadLine();

            var customer = new Customer(customerId, name, phoneNumber, email);
            rentalService.AddCustomer(customer);

            Console.WriteLine("Customer added successfully!");
        }

        static void AddVehicle(RentalService rentalService)
        {
            Console.Write("Enter Vehicle Registration Number: ");
            string regNumber = Console.ReadLine();
            Console.Write("Enter Make: ");
            string make = Console.ReadLine();
            Console.Write("Enter Model: ");
            string model = Console.ReadLine();
            Console.Write("Enter Year: ");
            int year = int.Parse(Console.ReadLine());
            Console.Write("Enter Rental Price Per Day: ");
            decimal price = decimal.Parse(Console.ReadLine());

            var vehicle = new Vehicle(regNumber, make, model, year, price);
            rentalService.AddVehicle(vehicle);

            Console.WriteLine("Vehicle added successfully!");
        }

        static void RentVehicle(RentalService rentalService)
        {
            Console.Write("Enter Customer ID: ");
            int customerId = int.Parse(Console.ReadLine());
            Console.Write("Enter Vehicle Registration Number: ");
            string regNumber = Console.ReadLine();
            Console.Write("Enter Rental Start Date (yyyy-mm-dd): ");
            DateTime startDate = DateTime.Parse(Console.ReadLine());
            Console.Write("Enter Rental End Date (yyyy-mm-dd): ");
            DateTime endDate = DateTime.Parse(Console.ReadLine());

            var customer = rentalService.GetCustomerById(customerId);
            var vehicle = rentalService.GetVehicleByRegistration(regNumber);

            if (customer == null || vehicle == null)
            {
                Console.WriteLine("Invalid Customer ID or Vehicle Registration Number.");
                return;
            }

            string result = rentalService.RentVehicle(customer, vehicle, startDate, endDate);
            Console.WriteLine(result);
        }

        static void ReturnVehicle(RentalService rentalService)
        {
            Console.Write("Enter Customer ID: ");
            int customerId = int.Parse(Console.ReadLine());
            Console.Write("Enter Vehicle Registration Number: ");
            string regNumber = Console.ReadLine();

            var customer = rentalService.GetCustomerById(customerId);
            var vehicle = rentalService.GetVehicleByRegistration(regNumber);

            if (customer == null || vehicle == null)
            {
                Console.WriteLine("Invalid Customer ID or Vehicle Registration Number.");
                return;
            }

            string result = rentalService.ReturnVehicle(customer, vehicle);
            Console.WriteLine(result);
        }

        static void ViewCustomerDetails(RentalService rentalService)
        {
            Console.Write("Enter Customer ID: ");
            int customerId = int.Parse(Console.ReadLine());

            var customer = rentalService.GetCustomerById(customerId);
            if (customer != null)
            {
                Console.WriteLine($"\nCustomer ID: {customer.CustomerId}");
                Console.WriteLine($"Name: {customer.Name}");
                Console.WriteLine($"Phone: {customer.PhoneNumber}");
                Console.WriteLine($"Email: {customer.Email}");
                Console.WriteLine("Rental History:");
                foreach (var transaction in customer.RentalHistory)
                {
                    Console.WriteLine($"  Transaction ID: {transaction.TransactionId}, Vehicle: {transaction.VehicleRegistrationNumber}, Start Date: {transaction.RentalStartDate}, End Date: {transaction.RentalEndDate}, Total: {transaction.TotalAmount}");
                }
            }
            else
            {
                Console.WriteLine("Customer not found.");
            }
        }

        static void ViewVehicleDetails(RentalService rentalService)
        {
            Console.Write("Enter Vehicle Registration Number: ");
            string regNumber = Console.ReadLine();

            var vehicle = rentalService.GetVehicleByRegistration(regNumber);
            if (vehicle != null)
            {
                Console.WriteLine($"\nRegistration Number: {vehicle.RegistrationNumber}");
                Console.WriteLine($"Maker: {vehicle.Make}");
                Console.WriteLine($"Model: {vehicle.Model}");
                Console.WriteLine($"Year: {vehicle.Year}");
                Console.WriteLine($"Rental Price Per Day: {vehicle.RentalPricePerDay}");
            }
            else
            {
                Console.WriteLine("Vehicle not found.");
            }
        }

        static void ViewTransactionDetails(RentalService rentalService)
        {
            Console.Write("Enter Customer ID: ");
            int customerId = int.Parse(Console.ReadLine());

            var customer = rentalService.GetCustomerById(customerId);
            if (customer != null)
            {
                Console.WriteLine($"Transactions for Customer ID: {customerId}");
                foreach (var transaction in customer.RentalHistory)
                {
                    Console.WriteLine($"  Transaction ID: {transaction.TransactionId}, Vehicle: {transaction.VehicleRegistrationNumber}, Start Date: {transaction.RentalStartDate}, End Date: {transaction.RentalEndDate}, Total Amount: {transaction.TotalAmount}");
                }
            }
            else
            {
                Console.WriteLine("No transactions found for this customer.");
            }
        }
    }
}
