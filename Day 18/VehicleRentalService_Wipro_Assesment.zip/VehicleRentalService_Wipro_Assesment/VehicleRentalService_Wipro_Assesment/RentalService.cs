﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace VehicleRentalService_Wipro_Assesment
{
    public class RentalService
    {
        private List<Vehicle> vehicles = new List<Vehicle>();
        private List<Customer> customers = new List<Customer>();
        private List<RentalTransaction> transactions = new List<RentalTransaction>();

        // Custom Delegate for Notifications
        public delegate void RentalNotification(string message);
        public event RentalNotification OnRentalProcessed;
        public event RentalNotification OnRentalCompleted;

        // Method to add a customer
        public void AddCustomer(Customer customer)
        {
            customers.Add(customer);
        }

        // Method to add a vehicle
        public void AddVehicle(Vehicle vehicle)
        {
            vehicles.Add(vehicle);
        }

        // Method to get customer by ID
        public Customer GetCustomerById(int customerId)
        {
            return customers.Find(c => c.CustomerId == customerId);
        }

        // Method to get vehicle by registration number
        public Vehicle GetVehicleByRegistration(string regNumber)
        {
            return vehicles.Find(v => v.RegistrationNumber == regNumber);
        }

        // Rent Vehicle Method
        public string RentVehicle(Customer customer, Vehicle vehicle, DateTime startDate, DateTime endDate)
        {
            if (!vehicles.Contains(vehicle))
                return "Vehicle not available.";

            var transaction = new RentalTransaction(transactions.Count + 1, customer.CustomerId, vehicle.RegistrationNumber, startDate, endDate, CalculateRentalFee(vehicle, startDate, endDate));
            customer.RentalHistory.Add(transaction);
            transactions.Add(transaction);

            OnRentalProcessed?.Invoke($"Rental processed for customer: {customer.Name} for vehicle: {vehicle.Make} {vehicle.Model}.");

            return "Rental successful.";
        }

        // Return Vehicle Method
        public string ReturnVehicle(Customer customer, Vehicle vehicle)
        {
            var transaction = customer.RentalHistory.LastOrDefault(t => t.VehicleRegistrationNumber == vehicle.RegistrationNumber);
            if (transaction == null)
                return "No active rental found for this vehicle.";

            OnRentalCompleted?.Invoke($"Rental completed for customer: {customer.Name} for vehicle: {vehicle.Make} {vehicle.Model}.");

            return "Vehicle returned successfully.";
        }

        // File I/O Handling for Transactions
        public void SaveTransactionsToFile(string filePath)
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                foreach (var transaction in transactions)
                {
                    writer.WriteLine($"Transaction ID: {transaction.TransactionId},  Customer ID: {transaction.CustomerId},  Vehicle Registration Number: {transaction.VehicleRegistrationNumber},  " + 
                                     $"Rent Start Date: {transaction.RentalStartDate},  Rent End Date: {transaction.RentalEndDate},  Total Rent Amount: {transaction.TotalAmount}");
                }
            }
        }
        public void LoadTransactionsFromFile(string filePath)
        {
            if (!File.Exists(filePath))
            {
                Console.WriteLine("File not found.");
                return;
            }

            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    try
                    {
                        var data = line.Split(',');

                        if (data.Length != 6)
                        {
                            Console.WriteLine($"Incorrect data format: {line}");
                            continue;
                        }

                        int transactionId;
                        int customerId;
                        DateTime rentalStartDate;
                        DateTime rentalEndDate;
                        decimal totalAmount;

                        bool isTransactionIdValid = int.TryParse(data[0], out transactionId);
                        bool isCustomerIdValid = int.TryParse(data[1], out customerId);
                        bool isRentalStartDateValid = DateTime.TryParse(data[3], out rentalStartDate);
                        bool isRentalEndDateValid = DateTime.TryParse(data[4], out rentalEndDate);
                        bool isTotalAmountValid = decimal.TryParse(data[5], out totalAmount);

                        if (!isTransactionIdValid || !isCustomerIdValid || !isRentalStartDateValid || !isRentalEndDateValid || !isTotalAmountValid)
                        {
                            Console.WriteLine($"Error parsing data: {line}");
                            continue;
                        }

                        var transaction = new RentalTransaction(
                            transactionId,
                            customerId,
                            data[2], // VehicleRegistrationNumber
                            rentalStartDate,
                            rentalEndDate,
                            totalAmount
                        );

                        transactions.Add(transaction);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error reading transaction: {ex.Message}");
                    }
                }
            }
        }

        // Filtering Vehicles using Predicate<T> Delegate
        public List<Vehicle> FilterAvailableVehicles(Predicate<Vehicle> predicate)
        {
            return vehicles.FindAll(predicate);
        }

        // Logging Transactions using Action<T> Delegate
        public void LogTransaction(Action<RentalTransaction> logAction)
        {
            foreach (var transaction in transactions)
            {
                logAction(transaction);
            }
        }

        // Calculating Rental Fee using Func<T> Delegate
        private decimal CalculateRentalFee(Vehicle vehicle, DateTime startDate, DateTime endDate)
        {
            Func<DateTime, DateTime, decimal> calculateFee = (start, end) =>
            {
                int days = (end - start).Days;
                return days * vehicle.RentalPricePerDay;
            };

            return calculateFee(startDate, endDate);
        }

        // Reflection
        public void LoadAndInvokeDynamicMethods()
        {
            string assemblyPath = Assembly.GetExecutingAssembly().Location;
            Assembly assembly = Assembly.LoadFrom(assemblyPath);

            // Load types related to Vehicle and Customer management
            var vehicleType = assembly.GetType("VehicleRentalService.Vehicle");
            var customerType = assembly.GetType("VehicleRentalService.Customer");

            if (vehicleType != null && customerType != null)
            {
                // Create an instance of Vehicle dynamically
                var vehicleInstance = Activator.CreateInstance(vehicleType, "AB123CD", "Toyota", "Camry", 2021, 150m);

                // Create an instance of Customer dynamically
                var customerInstance = Activator.CreateInstance(customerType, 1, "John Doe", "9876543210", "john@example.com");

                // Access and modify properties using reflection
                PropertyInfo vehicleModelProperty = vehicleType.GetProperty("Model");
                if (vehicleModelProperty != null && vehicleInstance != null)
                {
                    Console.WriteLine($"Original Vehicle Model: {vehicleModelProperty.GetValue(vehicleInstance)}");
                    vehicleModelProperty.SetValue(vehicleInstance, "Corolla");
                    Console.WriteLine($"Updated Vehicle Model: {vehicleModelProperty.GetValue(vehicleInstance)}");
                }

                PropertyInfo customerNameProperty = customerType.GetProperty("Name");
                if (customerNameProperty != null && customerInstance != null)
                {
                    Console.WriteLine($"Original Customer Name: {customerNameProperty.GetValue(customerInstance)}");
                    customerNameProperty.SetValue(customerInstance, "Jane Doe");
                    Console.WriteLine($"Updated Customer Name: {customerNameProperty.GetValue(customerInstance)}");
                }

                // Invoke methods dynamically
                MethodInfo addVehicleMethod = typeof(RentalService).GetMethod("AddVehicle");
                if (addVehicleMethod != null)
                {
                    addVehicleMethod.Invoke(this, new object[] { vehicleInstance });
                    Console.WriteLine("Vehicle added using reflection.");
                }

                MethodInfo addCustomerMethod = typeof(RentalService).GetMethod("AddCustomer");
                if (addCustomerMethod != null)
                {
                    addCustomerMethod.Invoke(this, new object[] { customerInstance });
                    Console.WriteLine("Customer added using reflection.");
                }
            }
        }
    }
}
